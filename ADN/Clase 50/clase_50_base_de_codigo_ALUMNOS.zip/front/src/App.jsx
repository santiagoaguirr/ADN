import UserTable from "./components/UserTable";
import "./App.css";

function App() {
  return (
    <>
      <UserTable />
    </>
  );
}

export default App;
