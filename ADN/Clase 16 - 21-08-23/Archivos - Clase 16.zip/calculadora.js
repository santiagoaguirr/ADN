const resolver = (operaciones,resultado) => {
    resultado = eval(operaciones);
    return resultado;
}
const elementoSumar = document.getElementById('sumar');
const elementoRestar = document.getElementById('restar');
const elementoMultiplicar = document.getElementById('multiplicar');
const elementoDividir = document.getElementById('dividir');
const elementoIgual = document.getElementById('igual');
const elementoC = document.getElementById('c');
const elementosNumeros = document.querySelectorAll('button');
const display = document.getElementById('display');
var operaciones = '';
var resultado = 0;
console.log(elementosNumeros);

for(let i=0; i<elementosNumeros.length; i++){
    elementosNumeros[i].addEventListener('click',(e) => {    
        if(e.target.value !== '=' && e.target.value !== 'c'){
            operaciones+=e.target.value;
            display.innerText=operaciones;
            console.log(operaciones);
        }else if ( e.target.value == 'c'){
            operaciones = '';
            display.innerText = operaciones;
        }else{
            resultado = resolver(operaciones,resultado);
            display.innerText= resultado;
            console.log(resultado);
            resultado =0;
            operaciones ='';
        }

    })
}

