let buttons = document.querySelectorAll('button');
let inputPesos = document.querySelector('#pesos');
let resultado = document.querySelector('#resultado');

const multiploDolar = 360;
const multiploEuro = 400;
const multiploReal = 71;
const multiploYuan = 48;

    buttons.forEach( b => {
        b.addEventListener('click' , () => {
            if (inputPesos.value) {      
                switch (b.id) {
                    case 'dolares': 
                        resultado.innerText = parseFloat(inputPesos.value)/multiploDolar;
                        break;
                    case 'euros': 
                        resultado.innerText = parseFloat(inputPesos.value)/multiploEuro;
                        break;
                    case 'reales': 
                        resultado.innerText = parseFloat(inputPesos.value)/multiploReal;
                        break;
                    case 'yuans': 
                        resultado.innerText = parseFloat(inputPesos.value)/multiploYuan;
                        break;
                    default:
                        break;
                }
            } else {
                resultado.innerText='Ingrese cantidad de Pesos';
            }
        })
    } )

    window.addEventListener('load', () => {
        alert('La página se ha cargado completamente.');
    });