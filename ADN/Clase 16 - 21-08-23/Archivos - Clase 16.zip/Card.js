let b1 = document.querySelector('#b1');
let b2 = document.querySelector('#b2');
let b3 = document.querySelector('#b3');
let b4 = document.querySelector('#b4');
let b5 = document.querySelector('#b5');
let buttons = [b1,b2,b3,b4,b5];

let titulo = document.querySelector('#titulo');
let titulos = ['Titulo 1','Titulo 2','Titulo 3','Titulo 4','Titulo 5'];

let parrafo = document.querySelector('#parrafo');
let parrafos = ['Parrafo titulo 1','Parrafo titulo 2','Parrafo titulo 3','Parrafo titulo 4','Parrafo titulo 5'];

const cambiarTituloParrafo = (t,p,fondos) => {
    titulo.innerText = t;
    parrafo.innerText = p;

}
    buttons.forEach((b,index) => {
        b.addEventListener('click', () => {
        cambiarTituloParrafo(titulos[index],parrafos[index]);
        })
    });
