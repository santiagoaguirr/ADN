const numero = document.querySelector('#numero');
// Tomo elementos botones
const botonSuma = document.querySelector('#suma');
const botonResta = document.querySelector('#resta');
const botonMultiplicacion = document.querySelector('#multiplicacion');
const botonDivision = document.querySelector('#division');
const display = document.querySelector('#display');

const botones = document.querySelectorAll('button')
let operacion = '';
let resultado = 0;
let operando = 0;

console.log(numero)
console.log("botones", botones)


numero.addEventListener('input', (evento) => {
  console.log("entró a la función")
  operando=evento.target.value;
  console.log("operando", operando)
  console.log("operacion", operacion)
})

for (let i = 0; i < botones.length; i++) {
  botones[i].addEventListener('click', (evento) => {
    if (evento.target.value !== '=') {
      operacion += operando + evento.target.value;
      display.innerText = operacion;
      operando = "";
      numero.value = "";
      console.log("operacion", operacion)
    }
    else {
      console.log("operacion", operacion)
      operacion += operando;
      resultado = eval(operacion);
      display.innerText = resultado;
      numero.value = "";
    }
  })
}



